// DBService.kt
import android.content.Context
import android.content.SharedPreferences

class DBService(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("AppPrefs", Context.MODE_PRIVATE)

    // Сохраняем данные
    fun saveUserData(className: String, profile: String, subgroup: String) {
        with(prefs.edit()) {
            putString("CLASS", className)
            putString("PROFILE", profile)
            putString("SUBGROUP", subgroup)
            apply()
        }
    }

    // Получаем сохраненный класс
    fun getSavedClass(): String? = prefs.getString("CLASS", null)

    // Получаем сохраненный профиль
    fun getSavedProfile(): String? = prefs.getString("PROFILE", null)

    // Получаем сохраненную подгруппу
    fun getSavedSubgroup(): String? = prefs.getString("SUBGROUP", null)
}