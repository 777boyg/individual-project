// MainActivity.kt
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ip.R

class MainActivity : AppCompatActivity() {
    private lateinit var dbService: DBService
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Инициализация DBService
        dbService = DBService(this)

        // Инициализация Spinner'ов (как в предыдущем коде)
        val classSpinner: Spinner = findViewById(R.id.classSpinner)
        val profileSpinner: Spinner = findViewById(R.id.profileSpinner)
        val subgroupSpinner: Spinner = findViewById(R.id.subgroupSpinner)

        // Настройка адаптеров...

        // Загрузка сохраненных данных
        loadSavedData(classSpinner, profileSpinner, subgroupSpinner)

        // Обработчик кнопки Сохранить
        val saveButton: Button = findViewById(R.id.saveButton)
        saveButton.setOnClickListener {
            val selectedClass = classSpinner.selectedItem.toString()
            val selectedProfile = profileSpinner.selectedItem.toString()
            val selectedSubgroup = subgroupSpinner.selectedItem.toString()

            // Сохраняем в SharedPreferences через DBService
            dbService.saveUserData(selectedClass, selectedProfile, selectedSubgroup)

            Toast.makeText(
                this,
                "Данные сохранены: Класс $selectedClass, Профиль $selectedProfile, Подгруппа $selectedSubgroup",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun loadSavedData(
        classSpinner: Spinner,
        profileSpinner: Spinner,
        subgroupSpinner: Spinner
    ) {
        // Получаем сохраненные данные
        val savedClass = dbService.getSavedClass()
        val savedProfile = dbService.getSavedProfile()
        val savedSubgroup = dbService.getSavedSubgroup()

        // Устанавливаем сохраненные значения в Spinner'ы
        savedClass?.let {
            val position = (classSpinner.adapter as ArrayAdapter<String>).getPosition(it)
            if (position >= 0) classSpinner.setSelection(position)
        }

        savedProfile?.let {
            val position = (profileSpinner.adapter as ArrayAdapter<String>).getPosition(it)
            if (position >= 0) profileSpinner.setSelection(position)
        }

        savedSubgroup?.let {
            val position = (subgroupSpinner.adapter as ArrayAdapter<String>).getPosition(it)
            if (position >= 0) subgroupSpinner.setSelection(position)
        }
        // Инициализация Spinner для класса
        val classSpinner: Spinner = findViewById(R.id.classSpinner)
        val classes = arrayOf("10", "11")
        val classAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, classes)
        classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        classSpinner.adapter = classAdapter

        // Инициализация Spinner для профиля
        val profileSpinner: Spinner = findViewById(R.id.profileSpinner)
        val profiles = arrayOf("мат1", "мат2", "линг1", "линг2", "мед1", "мед2", "био", "хим", "ист", "фил", "фм", "эк")
        val profileAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, profiles)
        profileAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        profileSpinner.adapter = profileAdapter

        // Инициализация Spinner для подгруппы
        val subgroupSpinner: Spinner = findViewById(R.id.subgroupSpinner)
        val subgroups = arrayOf("1", "2")
        val subgroupAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, subgroups)
        subgroupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        subgroupSpinner.adapter = subgroupAdapter

        // Обработчик кнопки Сохранить
        val saveButton: Button = findViewById(R.id.saveButton)
        saveButton.setOnClickListener {
            // Здесь можно добавить логику сохранения выбранных значений
            val selectedClass = classSpinner.selectedItem.toString()
            val selectedProfile = profileSpinner.selectedItem.toString()
            val selectedSubgroup = subgroupSpinner.selectedItem.toString()

            // Например, показать Toast с выбранными значениями
            Toast.makeText(this,
                "Выбрано: Класс $selectedClass, Профиль $selectedProfile, Подгруппа $selectedSubgroup",
                Toast.LENGTH_SHORT).show()
        }
    }
}