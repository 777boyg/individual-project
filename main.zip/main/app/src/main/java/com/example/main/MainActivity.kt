import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.example.main.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val scheduleButton = findViewById<Button>(R.id.scheduleButton)
        val eventsButton = findViewById<Button>(R.id.eventsButton)

        scheduleButton.setOnClickListener {
            // Здесь можно добавить переход на экран с расписанием пар
            // val intent = Intent(this, ScheduleActivity::class.java)
            // startActivity(intent)
        }

        eventsButton.setOnClickListener {
            // Здесь можно добавить переход на экран с расписанием мероприятий
            // val intent = Intent(this, EventsActivity::class.java)
            // startActivity(intent)
        }
    }
}